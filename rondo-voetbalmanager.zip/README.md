# RONDO — voetbalmanager

Een complete voetbalmanager die volledig in één HTML-bestand draait. Geen server, geen installatie:
open `index.html` en je speelt.

## Wat er in zit
- 9 competities (Premier League, Championship, La Liga, Serie A, Bundesliga, Ligue 1, Eredivisie,
  Primeira Liga, Pro League) plus 28 losse Europese clubs — 196 clubs en ~5.900 spelers
- Champions League, Europa League en Conference League in het huidige format (36 clubs, acht duels,
  tussenronde, knock-out) met een vijfjarige coëfficiëntenlijst
- Nationale bekers per land, interlandperiodes met een eindtoernooi, transfermarkt met
  onderhandelingen, deadline day, huurcontracten, scouting, training en een moraalsysteem
- Live wedstrijden minuut voor minuut met rustmoment, wissels en tactische bijsturing

## Online zetten via GitHub Pages
1. Maak een nieuwe repository aan (public).
2. Upload `index.html` in de hoofdmap.
3. Ga naar Settings → Pages → Source: `Deploy from a branch`, branch `main`, map `/ (root)`.
4. Na een minuut staat je spel op `https://<gebruikersnaam>.github.io/<repo>/`.

## Opslag
Het spel bewaart je carrière in de browser (localStorage) en heeft drie handmatige slots.
Saves zijn gzip-verpakt (~0,7 MB). Via Wereld → Opslaan kun je ook exporteren naar een bestand.

## Eigen clublogo's
Standaard tekent RONDO zelf een embleem per club. Heb je een eigen logopakket, vul dan bij
Wereld → Opslaan → Clublogo's een adres in met `{naam}`, `{slug}` of `{id}` als plek voor de club,
bijvoorbeeld `https://mijnsite.nl/logos/{slug}.png`. Werkt een logo niet, dan valt het spel
automatisch terug op de eigen tekening.
